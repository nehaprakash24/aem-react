self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "afa7d1d216a070360bed949605c6427f",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "d557d4cb1ecdb0dbbdc7",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.66ccd4dc.chunk.css"
  },
  {
    "revision": "26e359a559b2b8853cdc",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.7d6011ed.chunk.js"
  },
  {
    "revision": "e7d5bbb3f2be49be916aaab2fc075683",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.7d6011ed.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d557d4cb1ecdb0dbbdc7",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.66f2de79.chunk.js"
  },
  {
    "revision": "947a28bbb1bf3d46b68d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.b0e1d401.js"
  }
]);