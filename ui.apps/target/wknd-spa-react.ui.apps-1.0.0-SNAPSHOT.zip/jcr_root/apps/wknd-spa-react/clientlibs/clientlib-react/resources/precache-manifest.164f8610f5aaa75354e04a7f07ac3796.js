self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e235ea15e5d0c4f2b4d83c3e684e8393",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "a1aad5a494e4d6f78370",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.55c9da92.chunk.css"
  },
  {
    "revision": "cd37c0c3047ff6ab5fd2",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.47327829.chunk.js"
  },
  {
    "revision": "e7d5bbb3f2be49be916aaab2fc075683",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.47327829.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a1aad5a494e4d6f78370",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.6c07afb9.chunk.js"
  },
  {
    "revision": "947a28bbb1bf3d46b68d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.b0e1d401.js"
  },
  {
    "revision": "19a5bdabd660fde16554c866e650eadc",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/media/icon-back.19a5bdab.svg"
  }
]);