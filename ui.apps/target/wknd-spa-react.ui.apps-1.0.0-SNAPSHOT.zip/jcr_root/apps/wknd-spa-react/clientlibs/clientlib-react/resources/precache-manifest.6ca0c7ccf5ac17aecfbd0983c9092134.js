self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "16fc3e0e7eb69738f1079ac4f65c181f",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "d09dfaeef05982b6e416",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.fc63b834.chunk.css"
  },
  {
    "revision": "2a5b9f587f8924b882e9",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.a859ae91.chunk.js"
  },
  {
    "revision": "37daa3d0800b68d7b98fe74a6432e483",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.a859ae91.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d09dfaeef05982b6e416",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.3718232a.chunk.js"
  },
  {
    "revision": "947a28bbb1bf3d46b68d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.b0e1d401.js"
  }
]);