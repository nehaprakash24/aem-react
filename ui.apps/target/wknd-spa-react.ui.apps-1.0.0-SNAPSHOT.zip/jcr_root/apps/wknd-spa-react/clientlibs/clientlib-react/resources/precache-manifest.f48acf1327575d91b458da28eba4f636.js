self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bbb69c6c88e1432445208c3b416385bf",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "2bd7412fabb238d53768",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.e57bbe8a.chunk.css"
  },
  {
    "revision": "948f66e2ac9ca9f816b0",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.3c0d75ba.chunk.js"
  },
  {
    "revision": "e7d5bbb3f2be49be916aaab2fc075683",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.3c0d75ba.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2bd7412fabb238d53768",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.31d08420.chunk.js"
  },
  {
    "revision": "947a28bbb1bf3d46b68d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.b0e1d401.js"
  }
]);